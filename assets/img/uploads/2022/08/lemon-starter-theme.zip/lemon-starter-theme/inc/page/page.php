<h1><?php the_title(); ?></h1>
<?php the_post_thumbnail('banner-thumbnail'); ?>
<?php the_content(); ?>