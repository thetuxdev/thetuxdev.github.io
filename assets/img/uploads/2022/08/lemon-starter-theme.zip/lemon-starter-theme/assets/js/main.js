jQuery(document).ready(function ($) {
    // $('#scroll-to-top').fadeOut();

    $(document).scroll(function () {
        var y = $(this).scrollTop();
        if (y > 200) {
            $('#scroll-to-top').fadeIn();
        } else {
            $('#scroll-to-top').fadeOut();
        }
    });

    $("#scroll-to-top").click(function () {
        $(window).scrollTop(0);
    });

});
