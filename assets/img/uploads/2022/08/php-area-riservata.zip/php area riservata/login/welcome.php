<?php
define("PAGE", "Welcome");
include("layouts/header.php");
?>

<div class="container">
    <div class="box welcome">

        <h1>Login successful</h1>

    </div>
</div>

<?php
include("layouts/footer.php");
?>