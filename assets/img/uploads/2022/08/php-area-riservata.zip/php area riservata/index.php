<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" type="text/css" href="/login/assets/style.css">
    <title>Simple PHP Login</title>
</head>

<body>
    <div class="container">
        <div class="box">

            <a href="login/">
                <h1 style="color:#a3cce3">Login</h1>
            </a>

            <a href="login/register.php">
                <h1 style="color:#4f4f4f">Create New User</h1>
            </a>

        </div>
    </div>
</body>

</html>