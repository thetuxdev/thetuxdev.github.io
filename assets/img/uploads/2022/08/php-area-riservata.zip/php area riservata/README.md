# Simple php login and registration
Simple login and registration in php. This is a basic stack, you can integrate this with double password control, email notifications to new usert and more, it's just the basic for start a big project.

## What to do
  - Clone this repo into your website folder
  - Create a database in phpmyadmin
  - Import "user.sql" from database folder
  - Go to *your-website/login*
  - Insert the correct data in *login/utility/config.php*
  - Try with default user or create a new one 
  
*Default user:
    - Username: user
    - Email:    user@user.com
    - Password: Username1!*


