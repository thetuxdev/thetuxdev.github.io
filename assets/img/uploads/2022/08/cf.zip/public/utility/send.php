<?php
//Config File
include("config.php");

$email = $_POST['email'];
$object = $_POST['object'];
$message = $_POST['message'];

$to = 'your@email.com';
$subject = "New Contact from Simple PHP Contact Form";

$message = "
<html>
    <head>
        <title>Email from Simple PHP Contact Form</title>
    </head>
    <body>
        <b>Email:</b> <br>
        " . $email . " <br><br>
        <hr>
        <b>Object:</b> <br>
        " . $object . " <br><br>
        <hr>
        <b>Message:</b> <br>
        " . $message . " <br><br>
    </body>
</html>
";

// Always set content-type when sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// More headers
$headers .= 'From: Simple PHP Contact Form Script' . "\r\n";

if (mail($to, $subject, $message, $headers)) {
    header("location: ../?send=1");
    die();
} else {
    header("location: ../?send=0");
    die();
}