<?php
if (isset($_GET['send'])) {
    if ($_GET['send'] == 1) {
?>
        <div class="box success">
            <h1>Message Sent</h1>
        </div>
    <?php
    } else {
    ?>
        <div class="box error">
            <h1>a problem occurred</h1>
        </div>
<?php
    }
}
?>