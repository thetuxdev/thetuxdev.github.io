# Simple PHP Contact Form
Simple contact form in php. It send an email compiled from a form.

Just fill in `$to` variable your email address on line 9 of `utility/send.php`
