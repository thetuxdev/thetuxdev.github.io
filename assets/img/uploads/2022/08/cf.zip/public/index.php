<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" type="text/css" href="assets/style.css">
    <title>Simple PHP Contact Form</title>
</head>

<body>
    <div class="container">
        <div class="box">
            <?php include("utility/errors.php"); ?>

            <form class="" action="utility/send.php" method="POST">
                <h1>Simple Contact Form</h1>

                <label for="email">Email</label>
                <input autofocus name="email" type="email">

                <label for="object">Object</label>
                <input name="object" id="object" placeholder="" type="text">

                <label for="message">Message</label>
                <textarea name="message" id="message" cols="30" rows="5"></textarea>

                <button type="submit">Send</button>
            </form>
        </div>
    </div>
</body>

</html>